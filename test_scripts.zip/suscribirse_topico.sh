#!/bin/bash

# Función para mostrar el mensaje de ayuda
mostrar_ayuda() {
    echo "Uso: $0 -t TOPIC"
    echo ""
    echo "Opciones:"
    echo "  -t TOPIC    Tópico al que se suscribirá"
    echo "  -h          Mostrar esta ayuda y salir"
}

# Inicializar variables
BROKER="a3kqs7rhgdczgv-ats.iot.us-east-1.amazonaws.com" # Direccion del broker MQTT
PORT=8883  # Puerto del broker MQTT para conexiones seguras
CA_FILE="certs/AmazonRootCA1.pem"
CERT_FILE="certs/8ab048974966b0f77a64f8c96f7bc8f1c6db454170d8a03a5493708d10709217-certificate.pem.crt"
KEY_FILE="certs/8ab048974966b0f77a64f8c96f7bc8f1c6db454170d8a03a5493708d10709217-private.pem.key"
CLIENT_ID="iot-object-_e87c99c6"  # Client ID para la conexión MQTT
TOPIC=""

# Procesar argumentos de línea de comandos
while getopts ":t:h" opt; do
    case $opt in
        t)
            TOPIC=$OPTARG
            ;;
        h)
            mostrar_ayuda
            exit 0
            ;;
        \?)
            echo "Opción inválida: -$OPTARG" >&2
            mostrar_ayuda
            exit 1
            ;;
        :)
            echo "La opción -$OPTARG requiere un argumento." >&2
            mostrar_ayuda
            exit 1
            ;;
    esac
done

# Verificar que el argumento requerido está presente
if [ -z "$TOPIC" ]; then
    echo "Error: El argumento -t es requerido." >&2
    mostrar_ayuda
    exit 1
fi

# Ejecutar mosquitto_sub para suscribirse al tópico
mosquitto_sub --cafile "$CA_FILE" --cert "$CERT_FILE" --key "$KEY_FILE" -h "$BROKER" -p "$PORT" -t "$TOPIC" -i "$CLIENT_ID"
