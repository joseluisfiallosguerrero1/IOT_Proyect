#!/bin/bash

# Función para mostrar el mensaje de ayuda
mostrar_ayuda() {
    echo "Uso: $0 -b BROKER -t TOPIC -m MESSAGE"
    echo ""
    echo "Opciones:"
    echo "  -b BROKER   Dirección del broker MQTT"
    echo "  -t TOPIC    Tópico al que se enviará el mensaje"
    echo "  -m MESSAGE  Mensaje a enviar"
    echo "  -h          Mostrar esta ayuda y salir"
}

# Inicializar variables
BROKER=""
TOPIC=""
MESSAGE=""

# Procesar argumentos de línea de comandos
while getopts ":b:t:m:h" opt; do
    case $opt in
        b)
            BROKER=$OPTARG
            ;;
        t)
            TOPIC=$OPTARG
            ;;
        m)
            MESSAGE=$OPTARG
            ;;
        h)
            mostrar_ayuda
            exit 0
            ;;
        \?)
            echo "Opción inválida: -$OPTARG" >&2
            mostrar_ayuda
            exit 1
            ;;
        :)
            echo "La opción -$OPTARG requiere un argumento." >&2
            mostrar_ayuda
            exit 1
            ;;
    esac
done

# Verificar que todos los argumentos requeridos están presentes
if [ -z "$BROKER" ] || [ -z "$TOPIC" ] || [ -z "$MESSAGE" ]; then
    echo "Error: Todos los argumentos -b, -t y -m son requeridos." >&2
    mostrar_ayuda
    exit 1
fi

# Ejecutar mosquitto_pub para enviar el mensaje
mosquitto_pub -h "$BROKER" -t "$TOPIC" -m "$MESSAGE"

# Verificar si el mensaje fue enviado correctamente
if [ $? -eq 0 ]; then
    echo "Mensaje enviado correctamente a $TOPIC"
else
    echo "Error al enviar el mensaje"
fi

